import json

def lambda_handler(event,context):
    return{
        "stautsCode":200,
        "body":jason.dumps("Pravin, welcome to boto3")
}